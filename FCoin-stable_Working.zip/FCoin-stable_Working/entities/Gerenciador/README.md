## Dependencias
```
pip install flask
pip install flask_sqlalchemy
pip install flask_migrate
pip install Flask-RESTful
pip install dataclasses
```